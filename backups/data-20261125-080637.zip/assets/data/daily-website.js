// 主题数据: 每天挖掘一个神奇网站 (由 generate.py 生成)
window.TOPIC_DATA["daily-website"] = {
  "id": "daily-website",
  "title": "每天挖掘一个神奇网站",
  "slogan": "共收录 24 期,点击卡片跳转 B站观看",
  "source": {
    "platform": "B站",
    "name": "草根的异世界",
    "url": "https://space.bilibili.com/3690973370517975/video"
  },
  "page": "topics/daily-website.html",
  "count": 24,
  "videos": [
    {
      "title": "一个免费学汉语拼音的网站",
      "bv": "BV1JUs86EESY",
      "url": "https://www.bilibili.com/video/BV1JUs86EESY/",
      "cover": "https://i2.hdslb.com/bfs/archive/2a2da89665dc1cc8f21f1837861f833731fb51df.png",
      "views": "34",
      "date": "2026年11月19日",
      "ts": 1795090210,
      "author": "草根的异世界",
      "desc": "这里把23个声母、24个韵母、16个整体认读音节全部整理好了，点一下就能听到标准发音，跟着读就行。学完基础，还有专门的声调练习和完整音节表，一步一步帮掌握拼音。"
    },
    {
      "title": "一个免费学英语的网站",
      "bv": "BV15esS68EoG",
      "url": "https://www.bilibili.com/video/BV15esS68EoG/",
      "cover": "https://i1.hdslb.com/bfs/archive/4b646bd2b14416e0e0c57979c71a622dc8419dfc.jpg",
      "views": "29",
      "date": "2026年11月18日",
      "ts": 1794999385,
      "author": "草根的异世界",
      "desc": "不管你是刚入门的英语小白，还是想进一步提升的进阶选手，这里都能找到适合你的学习内容。它把英语学习分成了三个难度等级：Easy、Medium 和 Hard。\n如果你只会说Hello，就从 Easy 开始。这里有专门为初学者制作的对话视频，几分钟就能学会一些日常表达。"
    },
    {
      "title": "一个免费生成字帖的网站",
      "bv": "BV1Y8sw6oEoZ",
      "url": "https://www.bilibili.com/video/BV1Y8sw6oEoZ/",
      "cover": "https://i1.hdslb.com/bfs/archive/b22a5d5540ebec5395a91d62e2df0c410abada5b.jpg",
      "views": "50",
      "date": "2026年11月16日",
      "ts": 1794806444,
      "author": "草根的异世界",
      "desc": "这里不仅有语文字帖、英文字帖、数字字帖，甚至连拼音和控笔练习都能生成。你只需要输入想练习的文字，就能自动生成专属字帖。"
    },
    {
      "title": "一个直达全球动漫取景地的网站",
      "bv": "BV1R3s56tEwQ",
      "url": "https://www.bilibili.com/video/BV1R3s56tEwQ/",
      "cover": "https://i1.hdslb.com/bfs/archive/7506ac8eb7fb3875f57bfbefae34d5155fa19ad6.jpg",
      "views": "54",
      "date": "2026年11月14日",
      "ts": 1794655805,
      "author": "草根的异世界",
      "desc": "你能找到各种热门动漫的真实取景地，你只需要输入喜欢的动漫名称，地图上就会标出对应的取景地。点击地图标记，还能查看360度街景。"
    },
    {
      "title": "一个免费的资源宝库",
      "bv": "BV1QTWi62EjF",
      "url": "https://www.bilibili.com/video/BV1QTWi62EjF/",
      "cover": "https://i2.hdslb.com/bfs/archive/1bfc8ded579ed80df1e73fc25134627ae013e6e0.jpg",
      "views": "343",
      "date": "2026年11月13日",
      "ts": 1794569158,
      "author": "草根的异世界",
      "desc": "它是互联网上最大的免费资源库，各种影视资源、播客课程、绝版电子书，甚至成套的单机游戏大作，在这里几乎都能找到。"
    },
    {
      "title": "一个让你的桌面颜值封神的网站",
      "bv": "BV1N34z6pEHD",
      "url": "https://www.bilibili.com/video/BV1N34z6pEHD/",
      "cover": "https://i0.hdslb.com/bfs/archive/c3f39f735cea2eee88e5d1613091c8786b89f776.jpg",
      "views": "260",
      "date": "2026年11月6日",
      "ts": 1793974400,
      "author": "草根的异世界",
      "desc": "这里的高清壁纸连静态和动态壁纸都给你安排好了。无论你喜欢线稿、风景、动漫、水墨风还是治愈系，各种风格应有尽有。而且分辨率、色系、分类都可以按照自己的喜好筛选。不仅有电脑壁纸，还有手机壁纸。"
    },
    {
      "title": "一个让历史迷直接沉迷的网站",
      "bv": "BV1oc4w6eELC",
      "url": "https://www.bilibili.com/video/BV1oc4w6eELC/",
      "cover": "https://i0.hdslb.com/bfs/archive/ca93f478238a8352dc13b1a3d544c71e0a86298f.png",
      "views": "33",
      "date": "2026年11月2日",
      "ts": 1793620861,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站： 一个让历史迷直接沉迷的网站\n这里能找到世界各地几百年来的老地图，进入历史模式，拖动底部的时间轴，就能查看当时的统治者、著名战役，以及疆域变化。更有意思的是，能横向对比同一时期的世界发生了什么事。"
    },
    {
      "title": "一个帮你对比万物的网站",
      "bv": "BV1oHn86wEtE",
      "url": "https://www.bilibili.com/video/BV1oHn86wEtE/",
      "cover": "https://i0.hdslb.com/bfs/archive/3161ab9cf7a9de82bc4fcf0a5bb65edd2d7d126c.jpg",
      "views": "65",
      "date": "2026年10月23日",
      "ts": 1792768296,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站： 一个帮你对比万物的网站\n它收录了 106 个品类、九万四千多款产品，各种电子产品、家电，甚至食品，基本啥都能比；连学校和旅游地点，它都能给你分出高低。关键是不用花钱，直接就能用。"
    },
    {
      "title": "一个画画人没法拒绝的网站",
      "bv": "BV1QxnN6pE2C",
      "url": "https://www.bilibili.com/video/BV1QxnN6pE2C/",
      "cover": "https://i1.hdslb.com/bfs/archive/5fa825de3c004a693cae9a8a14aa701a6b105cb4.jpg",
      "views": "5454",
      "date": "2026年10月21日",
      "ts": 1792557000,
      "author": "草根的异世界",
      "desc": "你只要调整左侧的 3D 人体模型，摆出想要的动作，再选中需要参考的身体部位，它立马就能搜出一堆同款姿势的实拍参考图。这么好用的画画神器，关键是点开就能用，不用登录，还完全免费。"
    },
    {
      "title": "一个完全免费的PPT模板下载网站",
      "bv": "BV1EeJR6TEUU",
      "url": "https://www.bilibili.com/video/BV1EeJR6TEUU/",
      "cover": "https://i0.hdslb.com/bfs/archive/7971826b359bd0d286a0aab1e74f2a797bb217e1.jpg",
      "views": "95",
      "date": "2026年10月19日",
      "ts": 1792416060,
      "author": "草根的异世界",
      "desc": "这是一个完全免费的 PPT 模板下载网站，收录了超过 3700 多个模板，它不光有模板，还有 PPT 背景、图表、素材等各种免费资源，甚至连 PPT 教程都给你备好了。关键是无需登录，就能直接免费下载拿走！"
    },
    {
      "title": "一个可以免费生成全套儿童早教资料的网站",
      "bv": "BV1KwJv6tE2E",
      "url": "https://www.bilibili.com/video/BV1KwJv6tE2E/",
      "cover": "https://i1.hdslb.com/bfs/archive/e3aa748545a0c3cea92c03d576122dc89164425f.jpg",
      "views": "60",
      "date": "2026年10月17日",
      "ts": 1792218129,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站： 一个可以免费生成全套儿童早教资料的网站\n它收录了海量免费儿童练习题：基础的描红、走迷宫这类专注力游戏，还有字母表、涂色卡、词汇、形状、折纸等全都能找到，它还能一键生成定制版。还能免费下载保存！"
    },
    {
      "title": "一个免费学习地球各地方言的网站",
      "bv": "BV1mmJt6kE5A",
      "url": "https://www.bilibili.com/video/BV1mmJt6kE5A/",
      "cover": "https://i1.hdslb.com/bfs/archive/01cdeefe01e7ce18bf2b4834b675e0d0f59a6db3.jpg",
      "views": "59",
      "date": "2026年10月16日",
      "ts": 1792149238,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站： 一个免费学习地球各地方言的网站\n在这儿你能免费学 45 种方言，每种方言都配了120多节课，并且所有操作都不需要登录就可以免费使用。"
    },
    {
      "title": "这是一个能随意修改照片里文字的神奇工具",
      "bv": "BV1NqJk62EZZ",
      "url": "https://www.bilibili.com/video/BV1NqJk62EZZ/",
      "cover": "https://i0.hdslb.com/bfs/archive/2ec5e7918480f432e32b2ad72534f2f437a5ae50.jpg",
      "views": "31",
      "date": "2026年10月15日",
      "ts": 1792042298,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站：这是一个能随意修改照片里文字的神奇工具"
    },
    {
      "title": "一个能让你回到过去的网站",
      "bv": "BV19Rpo63ENM",
      "url": "https://www.bilibili.com/video/BV19Rpo63ENM/",
      "cover": "https://i1.hdslb.com/bfs/archive/eadcd967a7f953cc84f0ca1bee74afb16e89a9ee.jpg",
      "views": "105",
      "date": "2026年10月13日",
      "ts": 1791850200,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站： 一个能让你回到过去的网站\n这是一个免费的线上互联网档案馆，那些找不到的老书籍、怀旧电影、经典音乐，早已停更的旧软件，还有大量失传的复古小游戏，在这里基本都能挖到。"
    },
    {
      "title": "【第 10 期】一个由国家开放大学出品的终身教育平台",
      "bv": "BV1mnpn6fELP",
      "url": "https://www.bilibili.com/video/BV1mnpn6fELP/",
      "cover": "https://i1.hdslb.com/bfs/archive/dab15bba510fb516d96095169477e5d7dade2813.jpg",
      "views": "96",
      "date": "2026年10月11日",
      "ts": 1791726195,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站【第 10 期】一个由国家开放大学出品的终身教育平台\n它由国家开放大学出品，有我们常见的学外语、考公、考编、考研各类的学历技能，甚至健康，美食，居家，绘画等都能学，就连退休后的兴趣生活也没落下。"
    },
    {
      "title": "【第 9 期】一个免费给鼠标光标换皮肤的网站",
      "bv": "BV1jppg6mEnF",
      "url": "https://www.bilibili.com/video/BV1jppg6mEnF/",
      "cover": "https://i1.hdslb.com/bfs/archive/77d7515b7e692065ebd32a9f3408d301f62eff7f.jpg",
      "views": "2678",
      "date": "2026年10月10日",
      "ts": 1791628385,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站【第 9 期】一个免费给鼠标光标换皮肤的网站\n这里收录了一万多套鼠标光标，累计下载量已经超过 3400 万次。不管你是游戏党、动漫迷、卡通控，还是偏爱萌系可爱、表情包整活，都能在这挖到宝。"
    },
    {
      "title": "【第 8 期】一个免费教你维修任何电子设备的网站",
      "bv": "BV1RFp86PEQy",
      "url": "https://www.bilibili.com/video/BV1RFp86PEQy/",
      "cover": "https://i0.hdslb.com/bfs/archive/9038bf4d07b19fc6217d64f567778de2e2d4f928.jpg",
      "views": "67",
      "date": "2026年10月9日",
      "ts": 1791544448,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站【第 8 期】一个免费教你维修任何电子设备的网站\n每天有上千万人在用，它收录了几十万份维修指南和1亿次成功案例，从手机、电脑、游戏机、家用电器，基本你能想到的设备这里边儿都有。"
    },
    {
      "title": "【第 7 期】一个把复杂抽象的理科知识可视化的神级网站",
      "bv": "BV1QspK6fE67",
      "url": "https://www.bilibili.com/video/BV1QspK6fE67/",
      "cover": "https://i0.hdslb.com/bfs/archive/63498878bd90268f4cb36cc23af734ce30182796.jpg",
      "views": "110",
      "date": "2026年10月7日",
      "ts": 1791341553,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站【第 7 期】一个把复杂抽象的理科知识可视化的神级网站\n这是一个把复杂抽象的理科知识可视化的神级网站。\n它是由诺贝尔奖得主亲手创办的理科互动实验室，把物理、数学、化学、地理、生物的知识，全做成了交互式仿真程序，从小学一直覆盖到大学。学起来就像玩游戏。"
    },
    {
      "title": "【第 6 期】一个专治你做饭焦虑的网站",
      "bv": "BV1qrHx6dEzF",
      "url": "https://www.bilibili.com/video/BV1qrHx6dEzF/",
      "cover": "https://i1.hdslb.com/bfs/archive/172c64cf60b0e69b4b8553b7d31d3e321e6a1451.jpg",
      "views": "56",
      "date": "2026年10月5日",
      "ts": 1791209055,
      "author": "草根的异世界",
      "desc": "这是一个专治你做饭焦虑的网站。\n每道菜都有详细的视频教程，非常简单,关键是整个网站免注册、无广告，手机、电脑都能用，点开直接上手，专治你的做饭焦虑。"
    },
    {
      "title": "【第 5 期】一个让拼豆玩家实现拼豆自由的网站",
      "bv": "BV1U1H66JE5z",
      "url": "https://www.bilibili.com/video/BV1U1H66JE5z/",
      "cover": "https://i2.hdslb.com/bfs/archive/5aeb9200d084e6888b811f267cf5aca94af603d0.jpg",
      "views": "60",
      "date": "2026年10月4日",
      "ts": 1791095866,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站【第 5 期】一个让拼豆玩家实现拼豆自由的网站\n你只需给它一张图片，它就能立刻生成拼豆图纸。生成的高清图纸可以免费下载打印。关键是免费就能玩，还有多入口选择。"
    },
    {
      "title": "【第 4 期】一个可以免费学英语的网站",
      "bv": "BV1HWHY6HEXq",
      "url": "https://www.bilibili.com/video/BV1HWHY6HEXq/",
      "cover": "https://i1.hdslb.com/bfs/archive/79d2e06e32c5266d086bdfd96baad3cb7b6befed.jpg",
      "views": "55",
      "date": "2026年10月3日",
      "ts": 1791005939,
      "author": "草根的异世界",
      "desc": "你敢信吗？这个网站能让你省下几万的英语补课费！\n就算是英语小白，也能轻轻松松地学。"
    },
    {
      "title": "【第 3 期】一个可以免费收听世界各地电台的网站",
      "bv": "BV1tCam6cEVa",
      "url": "https://www.bilibili.com/video/BV1tCam6cEVa/",
      "cover": "https://i2.hdslb.com/bfs/archive/2a48c5f1ba4723bf0e4f17a7232f2d309b9d839d.jpg",
      "views": "67",
      "date": "2026年10月2日",
      "ts": 1790919066,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站【第 3 期】一个可以免费收听世界各地电台的网站\n这是一个能让你免费收听全世界各地电台的网站。 \n打开网站转动这颗小地球，亮起的每一个绿色小点，背后都是一座正在直播的电台，点击进去就能直接听到当地正在播出的节目。"
    },
    {
      "title": "【第 2 期】一个可以让你看全球公开实时摄像头的网站",
      "bv": "BV1UaYP6kEH9",
      "url": "https://www.bilibili.com/video/BV1UaYP6kEH9/",
      "cover": "https://i2.hdslb.com/bfs/archive/d096b03338cf7e9d481b776ad1504bdbdcfdefc2.jpg",
      "views": "55",
      "date": "2026年10月1日",
      "ts": 1790831200,
      "author": "草根的异世界",
      "desc": "每天挖掘一个神奇网站（第 2 期）你敢信在家动动手，就能看到全世界各地的实时景色。全球实时网络摄像头，让你足不出户环游世界各地。"
    },
    {
      "title": "【第 1 期】一个可以在网上自驾开遍全世界的网站",
      "bv": "BV1jHao6TEDs",
      "url": "https://www.bilibili.com/video/BV1jHao6TEDs/",
      "cover": "https://i0.hdslb.com/bfs/archive/6c86a1c83a65ac787af053afd19b307ceab932e0.jpg",
      "views": "33",
      "date": "2026年9月30日",
      "ts": 1790768057,
      "author": "草根的异世界",
      "desc": "在网上开启一场“全球自驾”。打开街道声，配上当地电台，瞬间就像坐进了当地的一辆车。不想开车，还能切换骑行和步行模式。"
    }
  ]
};
