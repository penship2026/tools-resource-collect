// 主题索引,由 generate.py 自动生成
const SITE = {
  name: "神奇网站挖掘机 · 视频聚合站",
  description: "按主题汇总各平台的神奇网站推荐视频,持续更新",
  updated: "2026-11-25",
};
const TOPIC_INDEX = [
  {
    "id": "daily-website",
    "title": "每天挖掘一个神奇网站",
    "slogan": "共收录 24 期,点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "草根的异世界",
      "url": "https://space.bilibili.com/3690973370517975/video"
    },
    "page": "topics/daily-website.html",
    "count": 24,
    "cover": "https://i2.hdslb.com/bfs/archive/2a2da89665dc1cc8f21f1837861f833731fb51df.png",
    "latest": "2026年11月19日"
  },
  {
    "id": "guwen-animation",
    "title": "跟着动画学古文",
    "slogan": "共收录 10 期,点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "宋歌资源库",
      "url": "https://space.bilibili.com/420996230/video"
    },
    "page": "topics/guwen-animation.html",
    "count": 10,
    "cover": "https://i0.hdslb.com/bfs/archive/7f02dcd6b7f7e4acfd0d1d82f4b6114c07ac9ce8.jpg",
    "latest": "2026年7月30日"
  },
  {
    "id": "topic-4e6ee53f",
    "title": "大模型对比",
    "slogan": "共收录 1 期,点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "明灯-专注脑洞一百年",
      "url": "https://space.bilibili.com/327838817/video"
    },
    "page": "topics/topic-4e6ee53f.html",
    "count": 1,
    "cover": "https://i0.hdslb.com/bfs/archive/cd52743195fa9e690f91595ccd588976ae7790cc.jpg",
    "latest": "2026年11月24日"
  },
  {
    "id": "topic-e5b5c763",
    "title": "英语启蒙必备",
    "slogan": "共收录 1 期,点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "爱学习的柒影",
      "url": "https://space.bilibili.com/3546645132216606/video"
    },
    "page": "topics/topic-e5b5c763.html",
    "count": 1,
    "cover": "https://i0.hdslb.com/bfs/archive/ebcd3c7807fb70574d651216cc4063b7e109c305.jpg",
    "latest": "2024年3月14日"
  },
  {
    "id": "topic-df282732",
    "title": "SpringAI",
    "slogan": "共收录 3 期,点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "徐庶AI实战",
      "url": "https://space.bilibili.com/3493131121068547/video"
    },
    "page": "topics/topic-df282732.html",
    "count": 3,
    "cover": "https://i2.hdslb.com/bfs/archive/7f4ef0ca45c592134ca812cbbeb587835e60b5a9.jpg",
    "latest": "2026年11月24日"
  },
  {
    "id": "topic-205064a1",
    "title": "最好的AI数字人项目",
    "slogan": "共收录 1 期,点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "小全栈",
      "url": "https://space.bilibili.com/3546724574431272/video"
    },
    "page": "topics/topic-205064a1.html",
    "count": 1,
    "cover": "https://i1.hdslb.com/bfs/archive/af3019f2d3d7066581996e4440caf9c9c20a7282.jpg",
    "latest": "2025年11月10日"
  },
  {
    "id": "topic-621ae722",
    "title": "数学思维启蒙动画",
    "slogan": "共收录 3 期,点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "乐乐的知识百宝箱",
      "url": "https://space.bilibili.com/3546621136603862/video"
    },
    "page": "topics/topic-621ae722.html",
    "count": 3,
    "cover": "https://i1.hdslb.com/bfs/archive/5fc2a47aa3ec4373d3206d1fb653d283ec61155c.jpg",
    "latest": "2026年3月30日"
  },
  {
    "id": "bv1j4w16reys",
    "title": "不上班靠AI提车买房！",
    "slogan": "单条视频精选 · 点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "椰子酱的AI日常",
      "url": "https://space.bilibili.com/3546380240947989/video"
    },
    "page": "topics/bv1j4w16reys.html",
    "count": 1,
    "cover": "http://i2.hdslb.com/bfs/archive/ca6323ceae54d29f7f5068dd8a98053d34fdc5c3.jpg",
    "latest": "2026年11月11日"
  },
  {
    "id": "bv1wg39zpetl",
    "title": "全158集【影子跟读英语新概念第一册动画",
    "slogan": "单条视频精选 · 点击卡片跳转 B站观看",
    "source": {
      "platform": "B站",
      "name": "学霸动画加油站",
      "url": "https://space.bilibili.com/3546927981398077/video"
    },
    "page": "topics/bv1wg39zpetl.html",
    "count": 1,
    "cover": "http://i2.hdslb.com/bfs/archive/b7fbf328a3897152dd482db5028b57726521e692.png",
    "latest": "2025年7月5日"
  }
];
