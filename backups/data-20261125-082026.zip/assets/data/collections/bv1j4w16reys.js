// 采集单元数据: 不上班靠AI提车买房！ (迁移自旧格式)
window.COLLECTION_DATA["bv1j4w16reys"] = {
  "id": "bv1j4w16reys",
  "title": "不上班靠AI提车买房！",
  "slogan": "单条视频精选 · 点击卡片跳转 B站观看",
  "source": {
    "platform": "B站",
    "name": "椰子酱的AI日常",
    "url": "https://space.bilibili.com/3546380240947989/video"
  },
  "page": "single.html?id=bv1j4w16reys",
  "count": 1,
  "videos": [
    {
      "title": "不上班靠AI提车买房！",
      "bv": "BV1J4W16REys",
      "url": "https://www.bilibili.com/video/BV1J4W16REys/",
      "cover": "http://i2.hdslb.com/bfs/archive/ca6323ceae54d29f7f5068dd8a98053d34fdc5c3.jpg",
      "views": "16463",
      "date": "2026年11月11日",
      "ts": 1794377617,
      "author": "椰子酱的AI日常",
      "desc": ""
    }
  ],
  "type": "single",
  "enabled": true,
  "created": "",
  "updated": "",
  "keyword": "",
  "cover": "http://i2.hdslb.com/bfs/archive/ca6323ceae54d29f7f5068dd8a98053d34fdc5c3.jpg",
  "latest": "2026年11月11日"
};
