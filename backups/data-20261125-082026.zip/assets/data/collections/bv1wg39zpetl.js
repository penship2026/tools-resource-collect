// 采集单元数据: 全158集【影子跟读英语新概念第一册动画 (迁移自旧格式)
window.COLLECTION_DATA["bv1wg39zpetl"] = {
  "id": "bv1wg39zpetl",
  "title": "全158集【影子跟读英语新概念第一册动画",
  "slogan": "单条视频精选 · 点击卡片跳转 B站观看",
  "source": {
    "platform": "B站",
    "name": "学霸动画加油站",
    "url": "https://space.bilibili.com/3546927981398077/video"
  },
  "page": "single.html?id=bv1wg39zpetl",
  "count": 1,
  "videos": [
    {
      "title": "全158集【影子跟读英语新概念第一册动画】(盲听+精学+影子跟读+成果检验)",
      "bv": "BV1WG39zPETL",
      "url": "https://www.bilibili.com/video/BV1WG39zPETL/",
      "cover": "http://i2.hdslb.com/bfs/archive/b7fbf328a3897152dd482db5028b57726521e692.png",
      "views": "4733158",
      "date": "2025年7月5日",
      "ts": 1751702532,
      "author": "学霸动画加油站",
      "desc": "全158集【影子跟读英语新概念第一册动画】(盲听+精学+影子跟读+成果检验)"
    }
  ],
  "type": "single",
  "enabled": true,
  "created": "",
  "updated": "",
  "keyword": "",
  "cover": "http://i2.hdslb.com/bfs/archive/b7fbf328a3897152dd482db5028b57726521e692.png",
  "latest": "2025年7月5日"
};
